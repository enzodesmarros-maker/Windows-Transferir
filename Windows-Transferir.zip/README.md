# Windows-Transferir

Área de transferência estilo **Win+V** e painel de emojis/kaomoji/símbolos estilo **Win+.** pro Android.

## Como funciona

- **Win+V** (teclado físico Bluetooth/OTG): abre o histórico da área de transferência (texto e imagem).
- **Win+.** ou **Win+;**: abre emojis, kaomoji e símbolos. **Esc** fecha.
- **Só no toque**: adicione os blocos "Área de transferência" e "Emojis" nas configurações rápidas.
- Tocar num item cola no campo de texto selecionado. 📌 fixa, ✕ apaga.
- Tudo roda local, sem internet.

## Instalar e ativar

1. Instale o APK.
2. Abra o app e toque em "Abrir configurações de acessibilidade", depois ative **Windows-Transferir**.
3. Android 13+: se a opção estiver cinza, vá em Info do app, 3 pontinhos, **Permitir configurações restritas**.

## Compilar pelo GitHub Actions

Já tem o workflow em `.github/workflows/build.yml`.

1. Suba esta pasta inteira num repositório do GitHub (branch `main`).
2. Aba **Actions**, abra a execução "Build APK".
3. Em **Artifacts**, baixe `Windows-Transferir-debug`, extraia o zip e instale o `app-debug.apk`.

## Limitações da v0.1

- Ler o clipboard em segundo plano é restrito no Android 10+. O app usa uma tela transparente que abre por um instante pra conseguir ler. Em alguns aparelhos isso pode falhar; a próxima versão terá suporte a **Shizuku**.
- Imagens: ao tocar, vão pro clipboard e você cola segurando no campo (depende do app aceitar).
