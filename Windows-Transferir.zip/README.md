# Windows-Transferir

Área de transferência estilo **Win+V** e painel de emojis/kaomoji/símbolos estilo **Win+.** pro Android.

## Como funciona

- **Win+V** (teclado físico Bluetooth/OTG): abre o histórico da área de transferência (texto e imagem).
- **Win+.** ou **Win+;**: abre emojis, kaomoji e símbolos. **Esc** fecha.
- **Só no toque**: adicione os blocos "Área de transferência" e "Emojis" nas configurações rápidas.
- Tocar num item cola no campo de texto selecionado. 📌 fixa, ✕ apaga.
- Tudo roda local, sem internet.

## Instalar e ativar

1. Instale o APK.
2. Abra o app e toque em "Abrir configurações de acessibilidade", depois ative **Windows-Transferir**.
3. Android 13+: se a opção estiver cinza, vá em Info do app, 3 pontinhos, **Permitir configurações restritas**.

## Compilar pelo GitHub Actions

Já tem o workflow em `.github/workflows/build.yml`.

1. Suba esta pasta inteira num repositório do GitHub (branch `main`).
2. Aba **Actions**, abra a execução "Build APK".
3. Em **Artifacts**, baixe `Windows-Transferir-debug`, extraia o zip e instale o `app-debug.apk`.

## Como captura o que você copia

O motor de detecção vem do [XClipper](https://github.com/KaustubhPatange/XClipper) (Apache 2.0, veja `NOTICE`):

- Heurísticas de acessibilidade: percebe o toque em "Copiar"/"Cortar" (no idioma do celular), seleção de texto e o aviso "Copiado".
- Uma tela transparente abre por meio segundo, ganha foco e lê o clipboard (no Android 10+ só quem está em foco pode ler).
- Detecção avançada (opcional): lê o logcat. Precisa de `adb shell pm grant com.clipplus android.permission.READ_LOGS` e da permissão de exibir sobre outros apps.

## Shizuku (sem computador)

A detecção avançada precisa de `READ_LOGS` e de "exibir sobre outros apps". Em vez de ADB no PC, o app usa o Shizuku:

1. Instale e inicie o Shizuku (Android 11+: "Iniciar via depuração sem fio").
2. No app, toque em **Conectar ao Shizuku e liberar tudo** e autorize.
3. O app libera as duas permissões e reinicia sozinho (religando a acessibilidade, sem mexer nos outros serviços).

Se o Shizuku já estiver autorizado, o app faz isso sozinho ao abrir.

## Atualizar sem desinstalar

O projeto usa uma chave de assinatura fixa (`app/debug.keystore`) e o `versionCode` cresce a cada build.
Por isso o APK novo instala por cima do antigo, mantendo permissões e histórico.
A chave é pública (está no repositório): serve pra uso pessoal. Pra publicar numa loja, use uma chave sua e secreta.
Na primeira vez que trocar de uma versão antiga (assinada com outra chave) pra esta, desinstale a antiga uma vez.

## Limitações

- Sem a detecção avançada, cópias feitas por botões que não geram evento de acessibilidade podem não ser capturadas.
- Imagens: ao tocar, vão pro clipboard e você cola segurando no campo (depende do app aceitar).
- Ainda não tem busca nos emojis.
