plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Cada build tem um versionCode maior que o anterior (minutos desde 1970), assim o APK novo
// sempre instala por cima do antigo. Pode ser trocado com -PversionCode=NN.
val buildVersionCode: Int =
    (project.findProperty("versionCode") as String?)?.toIntOrNull()
        ?: (System.currentTimeMillis() / 60000L).toInt()

android {
    namespace = "com.clipplus"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.clipplus"
        minSdk = 26
        targetSdk = 34
        versionCode = buildVersionCode
        versionName = "0.4.2"
    }

    // Chave FIXA (app/debug.keystore): como todo build usa a mesma assinatura, o Android aceita
    // atualizar sem desinstalar, mantendo permissões e histórico.
    signingConfigs {
        create("fixed") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    // O lint do release baixa mais coisa e pode barrar o build por detalhes que não afetam o app
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
