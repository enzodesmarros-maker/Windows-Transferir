# Roda pelo Shizuku (como shell). Reinicia o app e religa o serviço de acessibilidade,
# preservando os outros serviços de acessibilidade que o usuário já tinha ligados.
P=__PKG__
C=$P/__SERVICE__
S=$P/.ClipAccessibilityService

CUR=$(settings get secure enabled_accessibility_services)
[ "$CUR" = "null" ] && CUR=""
OTHERS=$(echo "$CUR" | tr ':' '\n' | grep -v "^$C\$" | grep -v "^$S\$" | grep -v '^$' | tr '\n' ':' | sed 's/:$//')

am force-stop $P
sleep 1

if [ -n "$OTHERS" ]; then
  settings put secure enabled_accessibility_services "$OTHERS"
else
  settings delete secure enabled_accessibility_services
fi
sleep 1

if [ -n "$OTHERS" ]; then NEW="$OTHERS:$C"; else NEW="$C"; fi
settings put secure enabled_accessibility_services "$NEW"
settings put secure accessibility_enabled 1
sleep 1
am start -n $P/.MainActivity
