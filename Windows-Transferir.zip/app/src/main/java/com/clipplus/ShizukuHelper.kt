package com.clipplus

import android.content.Context
import android.content.pm.PackageManager
import android.util.Base64
import rikka.shizuku.Shizuku

/**
 * Usa o Shizuku pra rodar, como shell, os comandos que antes precisavam de ADB no computador:
 *   pm grant <pkg> android.permission.READ_LOGS
 *   appops set <pkg> SYSTEM_ALERT_WINDOW allow
 * e pra reiniciar o app (a permissão de logs só vale num processo novo).
 */
object ShizukuHelper {
    const val REQUEST_CODE = 4242
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    private const val SCRIPT_PATH = "/data/local/tmp/windows_transferir_restart.sh"

    class Result(val ok: Boolean, val message: String)

    private class Out(val code: Int, val text: String)

    /** O Shizuku está instalado, iniciado e conectado com o app? */
    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    /** O usuário já autorizou este app dentro do Shizuku? */
    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** O usuário marcou "negar e não perguntar de novo" no Shizuku? */
    fun isPermissionBlocked(): Boolean = try {
        Shizuku.shouldShowRequestPermissionRationale()
    } catch (e: Throwable) {
        false
    }

    /**
     * Roda um comando como shell via Shizuku. O método newProcess é privado nas versões novas da
     * biblioteca, por isso a chamada é por reflexão (é o jeito usado pela comunidade).
     */
    private fun run(cmd: String): Out {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return Out(code, (out + err).trim())
    }

    /** Libera READ_LOGS e "exibir sobre outros apps". Bloqueia: chame fora da thread principal. */
    fun grant(context: Context): Result {
        val pkg = context.packageName
        return try {
            val problems = StringBuilder()

            val a = run("pm grant $pkg android.permission.READ_LOGS")
            if (a.code != 0) problems.append("READ_LOGS: ").append(a.text).append('\n')

            val b = run("appops set $pkg SYSTEM_ALERT_WINDOW allow")
            if (b.code != 0) problems.append("Exibir sobre outros apps: ").append(b.text).append('\n')

            if (problems.isEmpty()) Result(true, "Permissões liberadas") else Result(false, problems.toString().trim())
        } catch (e: Throwable) {
            Result(false, "Falhou: " + (e.cause?.message ?: e.message ?: e.javaClass.simpleName))
        }
    }

    /**
     * Reinicia o app e religa o serviço de acessibilidade (res/raw/restart_app.sh).
     * O script roda fora do app, por isso continua depois que o app é fechado.
     */
    fun restartApp(context: Context): Result {
        return try {
            val raw = context.resources.openRawResource(R.raw.restart_app).bufferedReader().use { it.readText() }
            val script = raw
                .replace("__PKG__", context.packageName)
                .replace("__SERVICE__", ClipAccessibilityService::class.java.name)
            val b64 = Base64.encodeToString(script.toByteArray(), Base64.NO_WRAP)

            val write = run("echo $b64 | base64 -d > $SCRIPT_PATH")
            if (write.code != 0) return Result(false, "Não consegui preparar o reinício: " + write.text)

            run("nohup sh $SCRIPT_PATH >/dev/null 2>&1 &")
            Result(true, "Reiniciando...")
        } catch (e: Throwable) {
            Result(false, "Falhou: " + (e.cause?.message ?: e.message ?: e.javaClass.simpleName))
        }
    }
}
