package com.clipplus

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Painel estilo Win+V / Win+. : abas de Área de transferência, Emojis, Kaomoji, Símbolos e Anotações.
 * Fica numa janela de overlay do serviço de acessibilidade (sem pedir permissão extra).
 */
class PanelView(
    context: Context,
    startTab: Int,
    private val cb: Callbacks
) : FrameLayout(context) {

    interface Callbacks {
        fun onPickClip(item: ClipItem)
        fun onPickSymbol(text: String, tab: Int)
        fun onClose()
        fun onTabChanged(tab: Int)
    }

    companion object {
        const val TAB_CLIP = 0
        const val TAB_EMOJI = 1
        const val TAB_KAOMOJI = 2
        const val TAB_SYMBOLS = 3
        const val TAB_NOTES = 4
    }

    var currentTab = -1
        private set

    private val tabViews = mutableListOf<TextView>()
    private val list = RecyclerView(context)
    private lateinit var clearBtn: TextView
    private lateinit var emptyView: TextView
    private lateinit var panelBox: LinearLayout
    private var landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private var imeBottom = 0

    // Aba de anotações
    private lateinit var notesBox: LinearLayout
    private lateinit var notesInput: EditText
    private val notesList = RecyclerView(context)
    private lateinit var selectionBar: LinearLayout
    private lateinit var selectionPreview: TextView
    private var selectedView: SelectableTextView? = null
    private var selectedText: String? = null

    private val clipAdapter = ClipAdapter(
        onPick = { cb.onPickClip(it) },
        onPin = { ClipStore.togglePin(it.id); refresh() },
        onDelete = { ClipStore.delete(it.id); refresh() }
    )

    private val gridAdapter = GridAdapter { cb.onPickSymbol(it, currentTab) }

    private val notesAdapter = NotesAdapter(
        onCopy = { copyText(it.text) },
        onDelete = { NotesStore.delete(it.id); refreshNotes(false) },
        onSelect = { view, text -> onNoteSelection(view, text) },
        onCopyText = { copyText(it) }
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundRect(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(12).toFloat()
        return d
    }

    init {
        NotesStore.init(context)
        setBackgroundColor(0x88000000.toInt())
        setOnClickListener { cb.onClose() }

        val panel = LinearLayout(context)
        panelBox = panel
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(8), dp(8), dp(8), dp(28))
        val bg = GradientDrawable()
        bg.setColor(0xFF2B2D31.toInt())
        val r = dp(20).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bg
        panel.setOnClickListener { }

        // Cabeçalho com as abas
        val header = LinearLayout(context)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val labels = listOf("📋", "😀", "ツ", "Ω", "📝")
        labels.forEachIndexed { index, label ->
            val tv = TextView(context)
            tv.text = label
            tv.textSize = 22f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(0xFFEDEDED.toInt())
            tv.setPadding(dp(8), dp(8), dp(8), dp(8))
            tv.setOnClickListener { selectTab(index) }
            header.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            tabViews.add(tv)
        }
        val close = TextView(context)
        close.text = "✕"
        close.textSize = 20f
        close.setTextColor(0xFF9AA0A6.toInt())
        close.setPadding(dp(14), dp(8), dp(14), dp(8))
        close.setOnClickListener { cb.onClose() }
        header.addView(
            close,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        panel.addView(
            header,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // Botão de limpar (só na aba da área de transferência)
        clearBtn = TextView(context)
        clearBtn.text = "Limpar tudo (mantém os fixados)"
        clearBtn.textSize = 13f
        clearBtn.setTextColor(0xFF9AA0A6.toInt())
        clearBtn.gravity = Gravity.END
        clearBtn.setPadding(dp(12), dp(6), dp(12), dp(6))
        clearBtn.setOnClickListener {
            ClipStore.clearUnpinned()
            refresh()
        }
        panel.addView(
            clearBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // Mensagem de lista vazia
        emptyView = TextView(context)
        emptyView.text = "Nada copiado ainda.\nCopie um texto ou imagem e ele aparece aqui."
        emptyView.textSize = 15f
        emptyView.gravity = Gravity.CENTER
        emptyView.setTextColor(0xFF9AA0A6.toInt())
        emptyView.setPadding(dp(16), dp(32), dp(16), dp(32))
        panel.addView(
            emptyView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        panel.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Aba de anotações: lista em cima (a mais nova embaixo) e a barra de digitação embaixo
        notesBox = LinearLayout(context)
        notesBox.orientation = LinearLayout.VERTICAL
        notesBox.visibility = View.GONE
        notesList.layoutManager = LinearLayoutManager(context)
        notesList.adapter = notesAdapter
        notesBox.addView(notesList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Barra que aparece quando há texto selecionado numa anotação
        selectionBar = LinearLayout(context)
        selectionBar.orientation = LinearLayout.HORIZONTAL
        selectionBar.gravity = Gravity.CENTER_VERTICAL
        selectionBar.visibility = View.GONE
        selectionBar.background = roundRect(0xFF3C4A63.toInt())
        selectionBar.setPadding(dp(12), dp(4), dp(4), dp(4))
        selectionPreview = TextView(context)
        selectionPreview.textSize = 13f
        selectionPreview.setTextColor(0xFFEDEDED.toInt())
        selectionPreview.maxLines = 1
        selectionPreview.ellipsize = TextUtils.TruncateAt.END
        selectionBar.addView(selectionPreview, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val copySel = TextView(context)
        copySel.text = "📋 Copiar seleção"
        copySel.textSize = 14f
        copySel.setTextColor(0xFF8AB4F8.toInt())
        copySel.setPadding(dp(10), dp(8), dp(10), dp(8))
        copySel.setOnClickListener {
            val t = selectedText
            if (t != null) copyText(t)
            selectedView?.clearSelection()
        }
        selectionBar.addView(
            copySel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        val clearSel = TextView(context)
        clearSel.text = "✕"
        clearSel.textSize = 16f
        clearSel.setTextColor(0xFF9AA0A6.toInt())
        clearSel.setPadding(dp(10), dp(8), dp(10), dp(8))
        clearSel.setOnClickListener { selectedView?.clearSelection() }
        selectionBar.addView(
            clearSel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        val selLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        selLp.topMargin = dp(4)
        notesBox.addView(selectionBar, selLp)

        val inputRow = LinearLayout(context)
        inputRow.orientation = LinearLayout.HORIZONTAL
        inputRow.gravity = Gravity.CENTER_VERTICAL
        inputRow.setPadding(0, dp(6), 0, 0)

        notesInput = EditText(context)
        notesInput.hint = "Digite uma anotação (Enter envia, Shift+Enter quebra linha)"
        notesInput.setHintTextColor(0xFF7C8085.toInt())
        notesInput.setTextColor(0xFFEDEDED.toInt())
        notesInput.textSize = 15f
        notesInput.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        notesInput.maxLines = 4
        notesInput.background = roundRect(0xFF383A40.toInt())
        notesInput.setPadding(dp(12), dp(10), dp(12), dp(10))
        notesInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && !event.isShiftPressed) {
                if (event.action == KeyEvent.ACTION_DOWN) sendNote()
                true
            } else {
                false
            }
        }
        inputRow.addView(notesInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Colar pelo toque (o menu de colar do Android também não funciona nesta janela)
        val pasteBtn = TextView(context)
        pasteBtn.text = "📥"
        pasteBtn.textSize = 20f
        pasteBtn.setPadding(dp(10), dp(8), dp(4), dp(8))
        pasteBtn.setOnClickListener { pasteIntoInput() }
        inputRow.addView(
            pasteBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val send = TextView(context)
        send.text = "➤"
        send.textSize = 24f
        send.setTextColor(0xFF8AB4F8.toInt())
        send.setPadding(dp(14), dp(8), dp(10), dp(8))
        send.setOnClickListener { sendNote() }
        inputRow.addView(
            send,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        notesBox.addView(
            inputRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        panel.addView(notesBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        addView(
            panel,
            FrameLayout.LayoutParams(dp(640), dp(320), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        )

        selectTab(startTab)
    }

    /**
     * O painel é montado uma vez só e reaproveitado, então o tamanho NÃO pode ser fixado na criação:
     * é calculado aqui, com o tamanho real da janela, toda vez que ela abre ou a tela gira.
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        if (w > 0 && h > 0) {
            val land = w > h
            val avail = maxOf(h - paddingBottom, dp(160)) // sem a parte coberta pelo teclado
            val newW = if (land) minOf(w, dp(720)) else minOf(w, dp(640))
            val factor = if (land) 0.92f else if (currentTab == TAB_NOTES) 0.62f else 0.55f
            val newH = minOf((h * factor).toInt(), avail)
            val lp = panelBox.layoutParams
            if (lp.width != newW || lp.height != newH) {
                lp.width = newW
                lp.height = newH
            }
            if (land != landscape) {
                landscape = land
                post { selectTab(currentTab) } // refaz as colunas da grade
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    /** Teclado na tela (só aparece na aba de anotações): levanta o painel pra não ficar escondido. */
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val ime = insets.getInsets(WindowInsets.Type.ime()).bottom
            if (ime != imeBottom) {
                imeBottom = ime
                setPadding(0, 0, 0, ime)
            }
        }
        return super.onApplyWindowInsets(insets)
    }

    /** Tecla Voltar fecha o painel (a janela só recebe teclas na aba de anotações). */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) cb.onClose()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    fun selectTab(index: Int) {
        currentTab = index
        for ((i, tv) in tabViews.withIndex()) {
            tv.background = if (i == index) roundRect(0x33FFFFFF) else null
        }
        val isNotes = index == TAB_NOTES
        notesBox.visibility = if (isNotes) View.VISIBLE else View.GONE
        list.visibility = if (isNotes) View.GONE else View.VISIBLE
        clearBtn.visibility = if (index == TAB_CLIP) View.VISIBLE else View.GONE

        if (isNotes) {
            // lista e campo de digitação ficam em notesBox
        } else if (index == TAB_CLIP) {
            list.layoutManager = LinearLayoutManager(context)
            list.adapter = clipAdapter
        } else {
            val span = if (landscape) {
                when (index) {
                    TAB_EMOJI -> 12
                    TAB_KAOMOJI -> 3
                    else -> 14
                }
            } else {
                when (index) {
                    TAB_EMOJI -> 7
                    TAB_KAOMOJI -> 2
                    else -> 8
                }
            }
            list.layoutManager = GridLayoutManager(context, span)
            list.adapter = gridAdapter
        }
        refresh()
        if (isNotes) {
            notesInput.requestFocus()
        } else {
            selectedView?.clearSelection()
            hideKeyboard()
            list.scrollToPosition(0)
        }
        cb.onTabChanged(index)
    }

    /** Chamado pelo serviço quando o histórico muda. */
    fun onStoreChanged() {
        if (currentTab == TAB_CLIP) refresh()
    }

    fun refresh() {
        when (currentTab) {
            TAB_CLIP -> {
                val items = ClipStore.snapshot()
                clipAdapter.set(items)
                emptyView.text = "Nada copiado ainda.\nCopie um texto ou imagem e ele aparece aqui."
                emptyView.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            }
            TAB_EMOJI -> {
                emptyView.visibility = View.GONE
                gridAdapter.set(Recents.get(context) + EmojiData.emojis, 26f)
            }
            TAB_KAOMOJI -> {
                emptyView.visibility = View.GONE
                gridAdapter.set(EmojiData.kaomoji, 16f)
            }
            TAB_NOTES -> {
                refreshNotes(true)
            }
            else -> {
                emptyView.visibility = View.GONE
                gridAdapter.set(EmojiData.symbols, 22f)
            }
        }
    }

    // ---------------------------------------------------------------- anotações

    private fun refreshNotes(scrollToEnd: Boolean) {
        val items = NotesStore.snapshot()
        notesAdapter.set(items)
        emptyView.text = "Nenhuma anotação ainda.\nEscreva na barra aí embaixo e toque em ➤."
        emptyView.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        if (scrollToEnd && items.isNotEmpty()) {
            notesList.post { notesList.scrollToPosition(items.size - 1) }
        }
    }

    private fun sendNote() {
        val t = notesInput.text.toString().trim()
        if (t.isEmpty()) return
        NotesStore.add(t)
        notesInput.setText("")
        refreshNotes(true)
    }

    /** Copia a anotação inteira. Como a janela está em foco, o histórico da área de transferência também registra. */
    private fun copyText(text: String) {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Windows-Transferir", text))
            Toast.makeText(context, "Copiado", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // ignora
        }
    }

    /** Chamado pelas anotações quando a seleção muda (texto selecionado, ou null). */
    private fun onNoteSelection(view: SelectableTextView, text: String?) {
        if (text != null) {
            val prev = selectedView
            if (prev != null && prev !== view) prev.clearSelection() // só uma seleção por vez
            selectedView = view
            selectedText = text
        } else if (selectedView === view) {
            selectedView = null
            selectedText = null
        }
        val t = selectedText
        if (t != null) {
            selectionPreview.text = "“" + t.replace('\n', ' ') + "”"
            selectionBar.visibility = View.VISIBLE
        } else {
            selectionBar.visibility = View.GONE
        }
    }

    /** Cola o que está na área de transferência na barra de digitação, na posição do cursor. */
    private fun pasteIntoInput() {
        try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(context)?.toString() else null
            if (t.isNullOrEmpty()) {
                Toast.makeText(context, "Nada pra colar", Toast.LENGTH_SHORT).show()
                return
            }
            val a = notesInput.selectionStart.coerceAtLeast(0)
            val b = notesInput.selectionEnd.coerceAtLeast(0)
            notesInput.text.replace(minOf(a, b), maxOf(a, b), t)
            notesInput.requestFocus()
        } catch (e: Exception) {
            Toast.makeText(context, "Não consegui colar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hideKeyboard() {
        notesInput.clearFocus()
        val token = windowToken ?: return
        try {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(token, 0)
        } catch (e: Exception) {
            // ignora
        }
    }

    // ---------------------------------------------------------------- adapters

    private class NotesAdapter(
        val onCopy: (NoteItem) -> Unit,
        val onDelete: (NoteItem) -> Unit,
        val onSelect: (SelectableTextView, String?) -> Unit,
        val onCopyText: (String) -> Unit
    ) : RecyclerView.Adapter<NotesAdapter.VH>() {

        private var data: List<NoteItem> = emptyList()

        fun set(d: List<NoteItem>) {
            data = d
            notifyDataSetChanged()
        }

        class VH(
            val row: LinearLayout,
            val tvBody: SelectableTextView,
            val tvCopy: TextView,
            val tvDel: TextView
        ) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c = parent.context
            val density = c.resources.displayMetrics.density
            fun px(v: Int): Int = (v * density).toInt()

            val row = LinearLayout(c)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(px(12), px(10), px(8), px(10))
            val rowBg = GradientDrawable()
            rowBg.setColor(0xFF383A40.toInt())
            rowBg.cornerRadius = px(12).toFloat()
            row.background = rowBg
            val rowLp = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            rowLp.setMargins(px(4), px(4), px(4), px(4))
            row.layoutParams = rowLp

            // Texto com seleção própria: arrastar com o mouse, ou segurar e arrastar com o dedo; Ctrl+C copia
            val tvBody = SelectableTextView(c)
            tvBody.setTextColor(0xFFEDEDED.toInt())
            tvBody.textSize = 15f
            tvBody.onSelectionChanged = onSelect
            tvBody.onCopy = onCopyText
            row.addView(tvBody, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val tvCopy = TextView(c)
            tvCopy.text = "📋"
            tvCopy.textSize = 18f
            tvCopy.setPadding(px(10), px(8), px(10), px(8))
            row.addView(
                tvCopy,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            val tvDel = TextView(c)
            tvDel.text = "✕"
            tvDel.textSize = 18f
            tvDel.setTextColor(0xFF9AA0A6.toInt())
            tvDel.setPadding(px(10), px(8), px(10), px(8))
            row.addView(
                tvDel,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            return VH(row, tvBody, tvCopy, tvDel)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = data[position]
            holder.tvBody.setNote(item.text)
            holder.tvCopy.setOnClickListener { onCopy(item) }
            holder.tvDel.setOnClickListener { onDelete(item) }
        }

        override fun getItemCount(): Int = data.size
    }

    private class GridAdapter(
        val onPick: (String) -> Unit
    ) : RecyclerView.Adapter<GridAdapter.VH>() {

        private var data: List<String> = emptyList()
        private var size = 26f

        fun set(d: List<String>, textSize: Float) {
            data = d
            size = textSize
            notifyDataSetChanged()
        }

        class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context)
            tv.gravity = Gravity.CENTER
            tv.setTextColor(0xFFEDEDED.toInt())
            val p = (8 * parent.resources.displayMetrics.density).toInt()
            tv.setPadding(p, p, p, p)
            tv.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            return VH(tv)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val s = data[position]
            holder.tv.textSize = size
            holder.tv.text = s
            holder.tv.setOnClickListener { onPick(s) }
        }

        override fun getItemCount(): Int = data.size
    }

    private class ClipAdapter(
        val onPick: (ClipItem) -> Unit,
        val onPin: (ClipItem) -> Unit,
        val onDelete: (ClipItem) -> Unit
    ) : RecyclerView.Adapter<ClipAdapter.VH>() {

        private var data: List<ClipItem> = emptyList()

        fun set(d: List<ClipItem>) {
            data = d
            notifyDataSetChanged()
        }

        class VH(
            val row: LinearLayout,
            val iv: ImageView,
            val tvBody: TextView,
            val tvPin: TextView,
            val tvDel: TextView
        ) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c = parent.context
            val density = c.resources.displayMetrics.density
            fun px(v: Int): Int = (v * density).toInt()

            val row = LinearLayout(c)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(px(12), px(10), px(8), px(10))
            val rowBg = GradientDrawable()
            rowBg.setColor(0xFF383A40.toInt())
            rowBg.cornerRadius = px(12).toFloat()
            row.background = rowBg
            val rowLp = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            rowLp.setMargins(px(4), px(4), px(4), px(4))
            row.layoutParams = rowLp

            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.visibility = View.GONE
            val ivLp = LinearLayout.LayoutParams(px(64), px(64))
            ivLp.rightMargin = px(10)
            row.addView(iv, ivLp)

            val tvBody = TextView(c)
            tvBody.setTextColor(0xFFEDEDED.toInt())
            tvBody.textSize = 15f
            tvBody.maxLines = 4
            tvBody.ellipsize = TextUtils.TruncateAt.END
            row.addView(tvBody, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val tvPin = TextView(c)
            tvPin.text = "📌"
            tvPin.textSize = 18f
            tvPin.setPadding(px(10), px(8), px(10), px(8))
            row.addView(
                tvPin,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            val tvDel = TextView(c)
            tvDel.text = "✕"
            tvDel.textSize = 18f
            tvDel.setTextColor(0xFF9AA0A6.toInt())
            tvDel.setPadding(px(10), px(8), px(10), px(8))
            row.addView(
                tvDel,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            return VH(row, iv, tvBody, tvPin, tvDel)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = data[position]
            val path = item.imagePath
            if (path != null) {
                holder.iv.visibility = View.VISIBLE
                holder.iv.setImageBitmap(decode(path, 192))
                holder.tvBody.text = "Imagem"
            } else {
                holder.iv.visibility = View.GONE
                holder.tvBody.text = item.text
            }
            holder.tvPin.alpha = if (item.pinned) 1f else 0.35f
            holder.row.setOnClickListener { onPick(item) }
            holder.tvPin.setOnClickListener { onPin(item) }
            holder.tvDel.setOnClickListener { onDelete(item) }
        }

        override fun getItemCount(): Int = data.size

        private fun decode(path: String, target: Int): Bitmap? {
            return try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                BitmapFactory.decodeFile(path, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                BitmapFactory.decodeFile(path, opts)
            } catch (e: Exception) {
                null
            }
        }
    }
}
