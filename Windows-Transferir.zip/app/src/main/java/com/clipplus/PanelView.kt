package com.clipplus

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Painel estilo Win+V / Win+. : abas de Área de transferência, Emojis, Kaomoji e Símbolos.
 * Fica numa janela de overlay do serviço de acessibilidade (sem pedir permissão extra).
 */
class PanelView(
    context: Context,
    startTab: Int,
    private val cb: Callbacks
) : FrameLayout(context) {

    interface Callbacks {
        fun onPickClip(item: ClipItem)
        fun onPickSymbol(text: String, tab: Int)
        fun onClose()
    }

    companion object {
        const val TAB_CLIP = 0
        const val TAB_EMOJI = 1
        const val TAB_KAOMOJI = 2
        const val TAB_SYMBOLS = 3
    }

    var currentTab = -1
        private set

    private val tabViews = mutableListOf<TextView>()
    private val list = RecyclerView(context)
    private lateinit var clearBtn: TextView
    private lateinit var emptyView: TextView

    private val clipAdapter = ClipAdapter(
        onPick = { cb.onPickClip(it) },
        onPin = { ClipStore.togglePin(it.id); refresh() },
        onDelete = { ClipStore.delete(it.id); refresh() }
    )

    private val gridAdapter = GridAdapter { cb.onPickSymbol(it, currentTab) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundRect(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(12).toFloat()
        return d
    }

    init {
        setBackgroundColor(0x88000000.toInt())
        setOnClickListener { cb.onClose() }

        val dm = resources.displayMetrics
        val panelWidth = minOf(dm.widthPixels, dp(640))
        val panelHeight = (dm.heightPixels * 0.55).toInt()

        val panel = LinearLayout(context)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(8), dp(8), dp(8), dp(28))
        val bg = GradientDrawable()
        bg.setColor(0xFF2B2D31.toInt())
        val r = dp(20).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = bg
        panel.setOnClickListener { }

        // Cabeçalho com as abas
        val header = LinearLayout(context)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val labels = listOf("📋", "😀", "ツ", "Ω")
        labels.forEachIndexed { index, label ->
            val tv = TextView(context)
            tv.text = label
            tv.textSize = 22f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(0xFFEDEDED.toInt())
            tv.setPadding(dp(8), dp(8), dp(8), dp(8))
            tv.setOnClickListener { selectTab(index) }
            header.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            tabViews.add(tv)
        }
        val close = TextView(context)
        close.text = "✕"
        close.textSize = 20f
        close.setTextColor(0xFF9AA0A6.toInt())
        close.setPadding(dp(14), dp(8), dp(14), dp(8))
        close.setOnClickListener { cb.onClose() }
        header.addView(
            close,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        panel.addView(
            header,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // Botão de limpar (só na aba da área de transferência)
        clearBtn = TextView(context)
        clearBtn.text = "Limpar tudo (mantém os fixados)"
        clearBtn.textSize = 13f
        clearBtn.setTextColor(0xFF9AA0A6.toInt())
        clearBtn.gravity = Gravity.END
        clearBtn.setPadding(dp(12), dp(6), dp(12), dp(6))
        clearBtn.setOnClickListener {
            ClipStore.clearUnpinned()
            refresh()
        }
        panel.addView(
            clearBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // Mensagem de lista vazia
        emptyView = TextView(context)
        emptyView.text = "Nada copiado ainda.\nCopie um texto ou imagem e ele aparece aqui."
        emptyView.textSize = 15f
        emptyView.gravity = Gravity.CENTER
        emptyView.setTextColor(0xFF9AA0A6.toInt())
        emptyView.setPadding(dp(16), dp(32), dp(16), dp(32))
        panel.addView(
            emptyView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        panel.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        addView(
            panel,
            FrameLayout.LayoutParams(panelWidth, panelHeight, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        )

        selectTab(startTab)
    }

    fun selectTab(index: Int) {
        currentTab = index
        for ((i, tv) in tabViews.withIndex()) {
            tv.background = if (i == index) roundRect(0x33FFFFFF) else null
        }
        clearBtn.visibility = if (index == TAB_CLIP) View.VISIBLE else View.GONE
        if (index == TAB_CLIP) {
            list.layoutManager = LinearLayoutManager(context)
            list.adapter = clipAdapter
        } else {
            val span = when (index) {
                TAB_EMOJI -> 7
                TAB_KAOMOJI -> 2
                else -> 8
            }
            list.layoutManager = GridLayoutManager(context, span)
            list.adapter = gridAdapter
        }
        refresh()
        list.scrollToPosition(0)
    }

    /** Chamado pelo serviço quando o histórico muda. */
    fun onStoreChanged() {
        if (currentTab == TAB_CLIP) refresh()
    }

    fun refresh() {
        when (currentTab) {
            TAB_CLIP -> {
                val items = ClipStore.snapshot()
                clipAdapter.set(items)
                emptyView.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            }
            TAB_EMOJI -> {
                emptyView.visibility = View.GONE
                gridAdapter.set(Recents.get(context) + EmojiData.emojis, 26f)
            }
            TAB_KAOMOJI -> {
                emptyView.visibility = View.GONE
                gridAdapter.set(EmojiData.kaomoji, 16f)
            }
            else -> {
                emptyView.visibility = View.GONE
                gridAdapter.set(EmojiData.symbols, 22f)
            }
        }
    }

    // ---------------------------------------------------------------- adapters

    private class GridAdapter(
        val onPick: (String) -> Unit
    ) : RecyclerView.Adapter<GridAdapter.VH>() {

        private var data: List<String> = emptyList()
        private var size = 26f

        fun set(d: List<String>, textSize: Float) {
            data = d
            size = textSize
            notifyDataSetChanged()
        }

        class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context)
            tv.gravity = Gravity.CENTER
            tv.setTextColor(0xFFEDEDED.toInt())
            val p = (8 * parent.resources.displayMetrics.density).toInt()
            tv.setPadding(p, p, p, p)
            tv.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            return VH(tv)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val s = data[position]
            holder.tv.textSize = size
            holder.tv.text = s
            holder.tv.setOnClickListener { onPick(s) }
        }

        override fun getItemCount(): Int = data.size
    }

    private class ClipAdapter(
        val onPick: (ClipItem) -> Unit,
        val onPin: (ClipItem) -> Unit,
        val onDelete: (ClipItem) -> Unit
    ) : RecyclerView.Adapter<ClipAdapter.VH>() {

        private var data: List<ClipItem> = emptyList()

        fun set(d: List<ClipItem>) {
            data = d
            notifyDataSetChanged()
        }

        class VH(
            val row: LinearLayout,
            val iv: ImageView,
            val tvBody: TextView,
            val tvPin: TextView,
            val tvDel: TextView
        ) : RecyclerView.ViewHolder(row)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c = parent.context
            val density = c.resources.displayMetrics.density
            fun px(v: Int): Int = (v * density).toInt()

            val row = LinearLayout(c)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(px(12), px(10), px(8), px(10))
            val rowBg = GradientDrawable()
            rowBg.setColor(0xFF383A40.toInt())
            rowBg.cornerRadius = px(12).toFloat()
            row.background = rowBg
            val rowLp = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            rowLp.setMargins(px(4), px(4), px(4), px(4))
            row.layoutParams = rowLp

            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.visibility = View.GONE
            val ivLp = LinearLayout.LayoutParams(px(64), px(64))
            ivLp.rightMargin = px(10)
            row.addView(iv, ivLp)

            val tvBody = TextView(c)
            tvBody.setTextColor(0xFFEDEDED.toInt())
            tvBody.textSize = 15f
            tvBody.maxLines = 4
            tvBody.ellipsize = TextUtils.TruncateAt.END
            row.addView(tvBody, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val tvPin = TextView(c)
            tvPin.text = "📌"
            tvPin.textSize = 18f
            tvPin.setPadding(px(10), px(8), px(10), px(8))
            row.addView(
                tvPin,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            val tvDel = TextView(c)
            tvDel.text = "✕"
            tvDel.textSize = 18f
            tvDel.setTextColor(0xFF9AA0A6.toInt())
            tvDel.setPadding(px(10), px(8), px(10), px(8))
            row.addView(
                tvDel,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            return VH(row, iv, tvBody, tvPin, tvDel)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = data[position]
            val path = item.imagePath
            if (path != null) {
                holder.iv.visibility = View.VISIBLE
                holder.iv.setImageBitmap(decode(path, 192))
                holder.tvBody.text = "Imagem"
            } else {
                holder.iv.visibility = View.GONE
                holder.tvBody.text = item.text
            }
            holder.tvPin.alpha = if (item.pinned) 1f else 0.35f
            holder.row.setOnClickListener { onPick(item) }
            holder.tvPin.setOnClickListener { onPin(item) }
            holder.tvDel.setOnClickListener { onDelete(item) }
        }

        override fun getItemCount(): Int = data.size

        private fun decode(path: String, target: Int): Bitmap? {
            return try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                BitmapFactory.decodeFile(path, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                BitmapFactory.decodeFile(path, opts)
            } catch (e: Exception) {
                null
            }
        }
    }
}
