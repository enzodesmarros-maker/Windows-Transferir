package com.clipplus

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ClipItem(
    val id: Long,
    val text: String?,
    val imagePath: String?,
    val time: Long,
    val pinned: Boolean = false
)

/** Histórico da área de transferência (texto e imagem), salvo em JSON no armazenamento interno. */
object ClipStore {
    private const val MAX_UNPINNED = 100
    private const val MAX_TEXT_LENGTH = 100_000

    private val items = mutableListOf<ClipItem>()
    private var loaded = false
    private lateinit var file: File
    private lateinit var imageDir: File

    @Volatile
    var onChange: (() -> Unit)? = null

    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val app = context.applicationContext
        file = File(app.filesDir, "history.json")
        imageDir = File(app.filesDir, "clips").apply { mkdirs() }
        if (file.exists()) {
            try {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    items.add(
                        ClipItem(
                            id = o.getLong("id"),
                            text = if (o.has("text")) o.getString("text") else null,
                            imagePath = if (o.has("img")) o.getString("img") else null,
                            time = o.getLong("time"),
                            pinned = o.optBoolean("pinned", false)
                        )
                    )
                }
            } catch (e: Exception) {
                // histórico corrompido: começa vazio
            }
        }
        loaded = true
    }

    /** Fixados primeiro, depois do mais novo pro mais antigo. */
    @Synchronized
    fun snapshot(): List<ClipItem> = items.sortedByDescending { it.pinned }

    @Synchronized
    fun newImageFile(ext: String): File =
        File(imageDir, "img_" + System.currentTimeMillis() + "." + ext)

    @Synchronized
    fun addText(text: String) {
        if (text.isBlank() || text.length > MAX_TEXT_LENGTH) return
        val old = items.firstOrNull { it.text == text }
        if (old != null) {
            items.remove(old)
            items.add(0, old.copy(time = System.currentTimeMillis()))
        } else {
            items.add(0, ClipItem(System.nanoTime(), text, null, System.currentTimeMillis()))
        }
        trimAndSave()
        onChange?.invoke()
    }

    @Synchronized
    fun addImage(path: String) {
        items.add(0, ClipItem(System.nanoTime(), null, path, System.currentTimeMillis()))
        trimAndSave()
        onChange?.invoke()
    }

    @Synchronized
    fun delete(id: Long) {
        val target = items.firstOrNull { it.id == id } ?: return
        target.imagePath?.let { File(it).delete() }
        items.remove(target)
        trimAndSave()
        onChange?.invoke()
    }

    @Synchronized
    fun togglePin(id: Long) {
        val index = items.indexOfFirst { it.id == id }
        if (index < 0) return
        val current = items[index]
        items[index] = current.copy(pinned = !current.pinned)
        trimAndSave()
        onChange?.invoke()
    }

    @Synchronized
    fun clearUnpinned() {
        for (item in items) {
            if (!item.pinned) item.imagePath?.let { File(it).delete() }
        }
        items.removeAll { !it.pinned }
        trimAndSave()
        onChange?.invoke()
    }

    private fun trimAndSave() {
        var unpinned = 0
        val iter = items.iterator()
        while (iter.hasNext()) {
            val item = iter.next()
            if (!item.pinned) {
                unpinned++
                if (unpinned > MAX_UNPINNED) {
                    item.imagePath?.let { File(it).delete() }
                    iter.remove()
                }
            }
        }
        val arr = JSONArray()
        for (item in items) {
            val o = JSONObject()
            o.put("id", item.id)
            if (item.text != null) o.put("text", item.text)
            if (item.imagePath != null) o.put("img", item.imagePath)
            o.put("time", item.time)
            o.put("pinned", item.pinned)
            arr.put(o)
        }
        try {
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // sem espaço / sem permissão: ignora
        }
    }
}

/** Emojis usados recentemente (aparecem primeiro na aba de emojis). */
object Recents {
    private const val PREFS = "windows_transferir"
    private const val KEY = "recent_emojis"

    fun get(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.split("\n").filter { it.isNotEmpty() }
    }

    fun add(context: Context, value: String) {
        val list = get(context).toMutableList()
        list.remove(value)
        list.add(0, value)
        val cut = list.take(24)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, cut.joinToString("\n"))
            .apply()
    }
}
