/*
 * Parte do motor de detecção de cópia adaptada do projeto XClipper (Android):
 * https://github.com/KaustubhPatange/XClipper
 * Copyright 2020 Kaustubh Patange
 * Licenciado sob a Apache License, Version 2.0 (veja o arquivo LICENSE na raiz).
 * Este arquivo foi MODIFICADO para o projeto Windows-Transferir (sem coroutines, usa Thread/Handler).
 */
package com.clipplus.engine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/**
 * No Android 10+ o sistema escreve "Denying clipboard access to <pacote> ..." no logcat quando um app
 * em segundo plano é avisado de que o clipboard mudou. Lendo o logcat dá pra saber que houve uma cópia
 * e abrir a tela transparente pra ler. Precisa da permissão READ_LOGS (liberada via ADB).
 */
interface ClipboardLogDetector {

    interface Listener {
        fun onClipboardEventDetected()
        fun onPermissionNotGranted()
    }

    fun registerListener(listener: Listener)
    fun startDetecting()
    fun stopDetecting()
    fun isStarted(): Boolean
    fun dispose()

    companion object {
        fun newInstanceCompat(context: Context): ClipboardLogDetector {
            return if (Build.VERSION.SDK_INT >= 29)
                ClipboardLogDetector29Impl(context)
            else
                ClipboardLogDetector21Impl()
        }

        fun hasReadLogs(context: Context): Boolean {
            return context.checkSelfPermission(Manifest.permission.READ_LOGS) == PackageManager.PERMISSION_GRANTED
        }

        fun hasOverlay(context: Context): Boolean = Settings.canDrawOverlays(context)

        fun isDetectionCompatible(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= 29)
                hasReadLogs(context) && hasOverlay(context)
            else
                false
        }
    }
}

private class ClipboardLogDetector29Impl(private val context: Context) : ClipboardLogDetector {
    private var listener: ClipboardLogDetector.Listener? = null
    private var currentTime: Long = 0

    @Volatile
    private var hasStarted: Boolean = false

    @Volatile
    private var process: Process? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun isStarted(): Boolean = hasStarted

    override fun registerListener(listener: ClipboardLogDetector.Listener) {
        this.listener = listener
    }

    override fun startDetecting() {
        if (!ClipboardLogDetector.isDetectionCompatible(context)) {
            listener?.onPermissionNotGranted()
            return
        }
        if (hasStarted) return
        hasStarted = true
        val pkg = context.packageName

        Thread {
            try {
                Runtime.getRuntime().exec("logcat -c").waitFor()
                val p = Runtime.getRuntime().exec("logcat e -T 1")
                process = p
                p.inputStream.bufferedReader().useLines { lines ->
                    for (line in lines) {
                        if (!hasStarted) break
                        if (line.contains("Denying") && line.contains("clipboard") && line.contains(pkg)) {
                            val now = System.currentTimeMillis()
                            if (now - currentTime > 500) {
                                currentTime = now
                                mainHandler.post { listener?.onClipboardEventDetected() }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // sem permissão ou logcat indisponível
            } finally {
                hasStarted = false
                process?.destroy()
                process = null
            }
        }.start()
    }

    override fun stopDetecting() {
        hasStarted = false
        process?.destroy()
    }

    override fun dispose() {
        listener = null
        stopDetecting()
    }
}

private class ClipboardLogDetector21Impl : ClipboardLogDetector {
    override fun dispose() { /* no-op */ }
    override fun registerListener(listener: ClipboardLogDetector.Listener) { /* no-op */ }
    override fun startDetecting() { /* no-op */ }
    override fun stopDetecting() { /* no-op */ }
    override fun isStarted(): Boolean = true
}
