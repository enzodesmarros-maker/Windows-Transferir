/*
 * Adaptada de ChangeClipboardActivity do projeto XClipper (Android):
 * https://github.com/KaustubhPatange/XClipper
 * Copyright 2020 Kaustubh Patange
 * Licenciado sob a Apache License, Version 2.0 (veja o arquivo LICENSE na raiz).
 * Este arquivo foi MODIFICADO para o projeto Windows-Transferir (sem Hilt/Room, grava no ClipStore).
 */
package com.clipplus.engine

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.clipplus.ClipCapture

/**
 * Tela transparente que abre por um instante só pra ganhar foco: no Android 10+ só o app em foco
 * consegue ler o clipboard. Espera 500ms (o XClipper notou que o sistema precisa desse tempo),
 * lê, guarda no histórico e fecha.
 */
class ChangeClipboardActivity : Activity() {

    companion object {
        @Volatile
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var done = false
    private var attempts = 0

    private val readRunnable = object : Runnable {
        override fun run() {
            if (done) return
            attempts++
            val ok = try {
                ClipCapture.capture(this@ChangeClipboardActivity)
            } catch (e: Exception) {
                false
            }
            if (ok || attempts >= 3) close() else handler.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        running = true
        // Trava de segurança: nunca fica aberta por mais de 3s
        handler.postDelayed({ close() }, 3000)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) schedule()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        attempts = 0
        schedule()
    }

    private fun schedule() {
        if (done) return
        handler.removeCallbacks(readRunnable)
        handler.postDelayed(readRunnable, 500)
    }

    private fun close() {
        if (done) return
        done = true
        finish()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
