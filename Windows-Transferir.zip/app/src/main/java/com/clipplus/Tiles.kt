package com.clipplus

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Blocos das configurações rápidas pra abrir o painel só com o toque (sem teclado físico). */
abstract class BaseTile(private val tab: Int) : TileService() {

    override fun onStartListening() {
        val t = qsTile ?: return
        t.state = Tile.STATE_INACTIVE
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        val service = ClipAccessibilityService.instance
        if (service == null) {
            // Serviço de acessibilidade desligado: abre o app pra ativar
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(
                    PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
                )
            } else {
                startActivityAndCollapse(i)
            }
            return
        }
        service.openFromTile(tab)
    }
}

class ClipTileService : BaseTile(PanelView.TAB_CLIP)

class EmojiTileService : BaseTile(PanelView.TAB_EMOJI)
