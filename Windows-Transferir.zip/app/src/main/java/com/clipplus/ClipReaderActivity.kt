package com.clipplus

import android.app.Activity
import android.os.Handler
import android.os.Looper

/**
 * Tela transparente que abre por um instante só pra ganhar foco e conseguir ler o clipboard
 * (no Android 10+ só quem está em primeiro plano pode ler). Fecha sozinha.
 */
class ClipReaderActivity : Activity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            try {
                ClipCapture.capture(this)
            } catch (e: Exception) {
                // ignora
            }
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        // Se por algum motivo nunca ganhar foco, fecha depois de 1s
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isFinishing) finish()
        }, 1000)
    }
}
