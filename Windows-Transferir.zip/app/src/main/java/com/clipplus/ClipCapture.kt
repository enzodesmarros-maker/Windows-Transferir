package com.clipplus

import android.content.ClipboardManager
import android.content.Context

/** Lê o que está na área de transferência do Android e guarda no histórico. */
object ClipCapture {

    /** Marcado quando o próprio app mexe no clipboard, pra não duplicar no histórico. */
    @Volatile
    var ignoreNext = false

    /** Último texto que o próprio app colocou no clipboard (emoji colado etc.), pra não entrar no histórico. */
    @Volatile
    var lastOwn: String? = null

    fun capture(context: Context): Boolean {
        ClipStore.init(context)
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = try {
            cm.primaryClip
        } catch (e: Exception) {
            null
        } ?: return false
        if (clip.itemCount == 0) return false

        val item = clip.getItemAt(0)
        val uri = item.uri
        if (uri != null && clip.description.hasMimeType("image/*")) {
            return try {
                val mime = clip.description.filterMimeTypes("image/*")?.firstOrNull() ?: "image/png"
                val ext = when {
                    mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
                    mime.contains("webp") -> "webp"
                    mime.contains("gif") -> "gif"
                    else -> "png"
                }
                val out = ClipStore.newImageFile(ext)
                val input = context.contentResolver.openInputStream(uri) ?: return false
                input.use { src -> out.outputStream().use { dst -> src.copyTo(dst) } }
                ClipStore.addImage(out.absolutePath)
                true
            } catch (e: Exception) {
                false
            }
        }

        val txt = try {
            item.coerceToText(context)?.toString()
        } catch (e: Exception) {
            null
        }
        if (!txt.isNullOrBlank()) {
            if (txt == lastOwn) return false
            lastOwn = null
            ClipStore.addText(txt)
            return true
        }
        return false
    }
}
