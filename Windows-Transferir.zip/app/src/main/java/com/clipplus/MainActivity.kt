package com.clipplus

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.clipplus.engine.ClipboardLogDetector
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var advanced: TextView
    private var autoTried = false
    private var busy = false

    // Resposta do pedido de autorização do Shizuku
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == ShizukuHelper.REQUEST_CODE) {
            runOnUiThread {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    grantViaShizuku()
                } else {
                    toast("Você negou o acesso no Shizuku")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClipStore.init(this)
        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // biblioteca do Shizuku indisponível: o app segue funcionando sem ela
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        col.addView(label("Windows-Transferir", 26f, true))
        col.addView(label(versionText(), 13f, false))
        status = label("", 16f, true)
        col.addView(status)
        advanced = label("", 14f, false)
        col.addView(advanced)
        col.addView(label(HOW_TO, 14f, false))

        col.addView(button("1) Abrir configurações de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("Android 13+: permitir configurações restritas") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        })
        col.addView(button("2) Conectar ao Shizuku e liberar tudo") {
            connectShizuku()
        })
        col.addView(button("3) Testar o painel agora") {
            val s = ClipAccessibilityService.instance
            if (s == null) {
                toast("Ative o serviço de acessibilidade primeiro")
            } else {
                s.toggle(PanelView.TAB_CLIP)
            }
        })
        col.addView(button("Reiniciar o app e a acessibilidade (via Shizuku)") {
            restartViaShizuku()
        })
        col.addView(button("Sem Shizuku: permitir exibir sobre outros apps") {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        })
        col.addView(button("Atualizar status") {
            refreshStatus()
        })

        val adb = label(ADB_HELP.replace("PKG", packageName), 13f, false)
        adb.setTextIsSelectable(true)
        col.addView(adb)

        setContentView(ScrollView(this).also { it.addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        // "Já conecta": se o Shizuku está rodando e já autorizou o app, libera o que falta sozinho
        if (!autoTried && ShizukuHelper.isRunning() && ShizukuHelper.hasPermission() && somethingMissing()) {
            autoTried = true
            grantViaShizuku()
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // ignora
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------ Shizuku

    private fun connectShizuku() {
        if (!ShizukuHelper.isRunning()) {
            val launch = packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
            if (launch != null) {
                toast("Inicie o Shizuku (ADB sem fio) e volte aqui")
                startActivity(launch)
            } else {
                toast("Instale o app Shizuku primeiro")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
            }
            return
        }
        if (ShizukuHelper.hasPermission()) {
            grantViaShizuku()
            return
        }
        if (ShizukuHelper.isPermissionBlocked()) {
            toast("Autorize o Windows-Transferir dentro do app Shizuku")
            val launch = packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE)
            if (launch != null) startActivity(launch)
            return
        }
        try {
            Shizuku.requestPermission(ShizukuHelper.REQUEST_CODE)
        } catch (e: Throwable) {
            toast("Não consegui pedir permissão ao Shizuku")
        }
    }

    private fun grantViaShizuku() {
        if (busy) return
        busy = true
        val hadLogs = Build.VERSION.SDK_INT < 29 || ClipboardLogDetector.hasReadLogs(this)
        toast("Liberando permissões...")
        Thread {
            val r = ShizukuHelper.grant(this)
            runOnUiThread {
                busy = false
                refreshStatus()
                if (!r.ok) {
                    toast(r.message)
                } else if (!hadLogs) {
                    toast("Pronto! Reiniciando o app pra aplicar...")
                    Thread {
                        Thread.sleep(1500)
                        ShizukuHelper.restartApp(this)
                    }.start()
                } else {
                    toast("Tudo liberado")
                }
            }
        }.start()
    }

    private fun restartViaShizuku() {
        if (!ShizukuHelper.isRunning() || !ShizukuHelper.hasPermission()) {
            toast("Conecte ao Shizuku primeiro (botão 2)")
            return
        }
        toast("Reiniciando...")
        Thread { ShizukuHelper.restartApp(this) }.start()
    }

    // ------------------------------------------------------------ status

    private fun somethingMissing(): Boolean {
        val logs = Build.VERSION.SDK_INT < 29 || ClipboardLogDetector.hasReadLogs(this)
        return !logs || !Settings.canDrawOverlays(this)
    }

    private fun refreshStatus() {
        status.text = if (serviceEnabled()) {
            "● Serviço ATIVO"
        } else {
            "○ Serviço desativado. Ative nas configurações de acessibilidade."
        }

        val logs = Build.VERSION.SDK_INT < 29 || ClipboardLogDetector.hasReadLogs(this)
        val overlay = Settings.canDrawOverlays(this)
        val running = ClipAccessibilityService.instance?.refreshAdvancedDetection() == true

        val shizuku = when {
            ShizukuHelper.isRunning() && ShizukuHelper.hasPermission() -> "conectado e autorizado"
            ShizukuHelper.isRunning() -> "rodando, falta autorizar (botão 2)"
            packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PACKAGE) != null -> "instalado, mas não iniciado"
            else -> "não instalado"
        }

        advanced.text = buildString {
            append("Shizuku: ").append(shizuku)
            append("\nDetecção avançada (logcat): ")
            append(
                if (Build.VERSION.SDK_INT < 29) "não precisa nesta versão do Android"
                else if (running) "ATIVA"
                else "desligada"
            )
            append("\n  • Permissão READ_LOGS: ").append(if (logs) "ok" else "falta")
            append("\n  • Exibir sobre outros apps: ").append(if (overlay) "ok" else "falta")
        }
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { entry ->
            val cn = ComponentName.unflattenFromString(entry)
            cn != null &&
                cn.packageName == packageName &&
                cn.className == ClipAccessibilityService::class.java.name
        }
    }

    /** Mostra versão e data da compilação: serve pra conferir se o APK novo mesmo foi instalado. */
    @Suppress("DEPRECATION")
    private fun versionText(): String {
        return try {
            val info = packageManager.getPackageInfo(packageName, 0)
            // o versionCode é o "minuto" em que o APK foi compilado (veja app/build.gradle.kts)
            val built = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(info.versionCode.toLong() * 60000L))
            "Versão " + info.versionName + " • compilada em " + built
        } catch (e: Exception) {
            "Versão desconhecida"
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun label(s: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        val p = (8 * resources.displayMetrics.density).toInt()
        t.setPadding(0, p, 0, p)
        return t
    }

    private fun button(title: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = title
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    companion object {
        private val HOW_TO = """
Como usar
• Teclado físico (Bluetooth/OTG): Win+V abre a área de transferência. Win+. (ou Win+;) abre emojis, kaomoji e símbolos. Esc fecha.
• Só no toque: puxe a barra de status, toque no lápis das configurações rápidas e arraste os blocos "Área de transferência" e "Emojis".
• Toque num item pra colar no campo de texto selecionado. 📌 fixa, ✕ apaga.
• Aba 📝 (anotações): escreva na barra de baixo e envie com Enter ou ➤ (Shift+Enter quebra a linha). Dá pra selecionar o texto com o mouse/dedo e usar Ctrl+C e Ctrl+V. O botão 📋 copia a anotação inteira. Fica salva no aparelho.

Como ele captura o que você copia (Android 10+)
• O motor vem do XClipper: percebe o toque em "Copiar" / "Cortar" (no idioma do celular) e abre uma tela transparente por meio segundo pra ler o clipboard. Pode piscar rapidinho ao copiar, é normal.
• A detecção avançada (logcat) pega TODA cópia. Precisa da permissão READ_LOGS e de "exibir sobre outros apps". O botão 2 libera as duas pelo Shizuku, sem computador, e reinicia o app sozinho.

Importante
• Android 13+: se a acessibilidade estiver cinza, use o botão de configurações restritas, toque nos 3 pontinhos e escolha "Permitir configurações restritas".
• Imagens: ao tocar, vão pro clipboard. Cole segurando no campo (depende do app aceitar).
        """.trimIndent()

        private val ADB_HELP = """
Sem Shizuku? Pelo computador com depuração USB:
adb shell pm grant PKG android.permission.READ_LOGS
adb shell appops set PKG SYSTEM_ALERT_WINDOW allow
Depois force a parada do app e reative a acessibilidade.
        """.trimIndent()
    }
}
