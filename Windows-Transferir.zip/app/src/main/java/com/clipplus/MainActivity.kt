package com.clipplus

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClipStore.init(this)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        col.addView(label("Windows-Transferir", 26f, true))
        status = label("", 16f, true)
        col.addView(status)
        col.addView(label(HOW_TO, 14f, false))

        col.addView(button("1) Abrir configurações de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("Android 13+: permitir configurações restritas") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        })
        col.addView(button("2) Testar o painel agora") {
            val s = ClipAccessibilityService.instance
            if (s == null) {
                Toast.makeText(this, "Ative o serviço de acessibilidade primeiro", Toast.LENGTH_LONG).show()
            } else {
                s.toggle(PanelView.TAB_CLIP)
            }
        })

        setContentView(ScrollView(this).also { it.addView(col) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (serviceEnabled()) {
            "● Serviço ATIVO"
        } else {
            "○ Serviço desativado. Ative nas configurações de acessibilidade."
        }
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { entry ->
            val cn = ComponentName.unflattenFromString(entry)
            cn != null &&
                cn.packageName == packageName &&
                cn.className == ClipAccessibilityService::class.java.name
        }
    }

    private fun label(s: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        val p = (8 * resources.displayMetrics.density).toInt()
        t.setPadding(0, p, 0, p)
        return t
    }

    private fun button(title: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = title
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    companion object {
        private val HOW_TO = """
Como usar
• Teclado físico (Bluetooth/OTG): Win+V abre a área de transferência. Win+. (ou Win+;) abre emojis, kaomoji e símbolos. Esc fecha.
• Só no toque: puxe a barra de status, toque no lápis das configurações rápidas e arraste os blocos "Área de transferência" e "Emojis".
• Toque num item pra colar no campo de texto selecionado. 📌 fixa, ✕ apaga.

Importante
• Android 13+: se a acessibilidade estiver cinza, use o botão de configurações restritas abaixo, toque nos 3 pontinhos e escolha "Permitir configurações restritas".
• O Android 10+ não deixa apps lerem o clipboard em segundo plano. O app tenta com uma tela transparente que abre por um instante. Se não capturar no seu celular, a próxima versão usa o Shizuku.
• Imagens: ao tocar, vão pro clipboard. Cole segurando no campo (depende do app aceitar).
        """.trimIndent()
    }
}
