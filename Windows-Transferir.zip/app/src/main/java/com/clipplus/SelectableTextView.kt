package com.clipplus

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.style.BackgroundColorSpan
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.TextView

/**
 * TextView com seleção PRÓPRIA.
 *
 * A seleção nativa do Android depende de um "ActionMode" (a barrinha de copiar/colar), que não existe
 * numa janela de overlay de acessibilidade, por isso ela não funcionava no painel. Aqui:
 *  - mouse: arrastar com o botão esquerdo seleciona;
 *  - dedo: segurar e arrastar seleciona (começa pela palavra tocada);
 *  - Ctrl+A seleciona tudo; Ctrl+C copia a seleção (ou a anotação toda, se não houver seleção);
 *  - a seleção é só um destaque (span), e quem copia é o painel (barra "Copiar seleção").
 */
class SelectableTextView(context: Context) : TextView(context) {

    /** Avisa quando a seleção muda: texto selecionado, ou null se não há mais seleção. */
    var onSelectionChanged: ((SelectableTextView, String?) -> Unit)? = null

    /** Pedido de cópia pelo teclado (Ctrl+C). */
    var onCopy: ((String) -> Unit)? = null

    private val uiHandler = Handler(Looper.getMainLooper())
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val highlight = BackgroundColorSpan(0x668AB4F8)

    private var selStart = -1
    private var selEnd = -1
    private var anchorStart = 0
    private var anchorEnd = 0
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var downOffset = 0

    private val longPress = Runnable {
        // Dedo segurado sem mover: começa a seleção pela palavra tocada e deixa arrastar
        val range = wordBounds(downOffset)
        anchorStart = range.first
        anchorEnd = range.second
        dragging = true
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        setSel(anchorStart, anchorEnd)
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    /** Troca o texto (o RecyclerView reaproveita as linhas) e zera a seleção. */
    fun setNote(value: String) {
        uiHandler.removeCallbacks(longPress)
        dragging = false
        val had = hasSelection()
        selStart = -1
        selEnd = -1
        setText(value, TextView.BufferType.SPANNABLE)
        if (had) onSelectionChanged?.invoke(this, null)
    }

    fun hasSelection(): Boolean = selStart >= 0 && selEnd > selStart

    fun selectedText(): String? =
        if (hasSelection()) text.subSequence(selStart, selEnd).toString() else null

    fun clearSelection() {
        if (hasSelection()) setSel(-1, -1)
    }

    private fun setSel(start: Int, end: Int) {
        val sp = text as? Spannable ?: return
        sp.removeSpan(highlight)
        if (start >= 0 && end > start && end <= sp.length) {
            sp.setSpan(highlight, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            selStart = start
            selEnd = end
        } else {
            selStart = -1
            selEnd = -1
        }
        onSelectionChanged?.invoke(this, selectedText())
    }

    private fun offsetAt(event: MotionEvent): Int {
        val off = getOffsetForPosition(event.x, event.y)
        return if (off < 0) 0 else off
    }

    private fun isWordChar(c: Char): Boolean = Character.isLetterOrDigit(c) || c == '_'

    private fun wordBounds(off: Int): Pair<Int, Int> {
        val t = text
        if (t.isEmpty()) return Pair(0, 0)
        var s = off.coerceIn(0, t.length)
        var e = s
        while (s > 0 && isWordChar(t[s - 1])) s--
        while (e < t.length && isWordChar(t[e])) e++
        if (s == e && e < t.length) e++ // tocou num espaço ou pontuação: seleciona 1 caractere
        return Pair(s, e)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val mouse = event.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                downOffset = offsetAt(event)
                dragging = false
                requestFocus() // pra receber Ctrl+C / Ctrl+A do teclado
                if (mouse) {
                    if (!event.isButtonPressed(MotionEvent.BUTTON_PRIMARY)) {
                        return super.onTouchEvent(event)
                    }
                    anchorStart = downOffset
                    anchorEnd = downOffset
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    clearSelection() // clique novo limpa a seleção anterior
                } else {
                    uiHandler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    val off = offsetAt(event)
                    val s = if (off < anchorStart) off else anchorStart
                    val e = if (off > anchorEnd) off else anchorEnd
                    setSel(s, e)
                } else if (Math.abs(event.x - downX) > touchSlop || Math.abs(event.y - downY) > touchSlop) {
                    uiHandler.removeCallbacks(longPress) // virou rolagem da lista
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                uiHandler.removeCallbacks(longPress)
                // toque simples (sem segurar nem arrastar) tira a seleção
                if (event.actionMasked == MotionEvent.ACTION_UP && !dragging && !mouse) clearSelection()
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.isCtrlPressed) {
            if (keyCode == KeyEvent.KEYCODE_C) {
                onCopy?.invoke(selectedText() ?: text.toString())
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_A) {
                setSel(0, text.length)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDetachedFromWindow() {
        uiHandler.removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }
}
