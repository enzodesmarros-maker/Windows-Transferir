package com.clipplus

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class NoteItem(
    val id: Long,
    val text: String,
    val time: Long
)

/** Anotações do usuário (aba 📝 do painel), salvas em JSON no armazenamento interno do app. */
object NotesStore {
    private val items = mutableListOf<NoteItem>()
    private var loaded = false
    private lateinit var file: File

    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        file = File(context.applicationContext.filesDir, "notes.json")
        if (file.exists()) {
            try {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    items.add(NoteItem(o.getLong("id"), o.getString("text"), o.getLong("time")))
                }
            } catch (e: Exception) {
                // arquivo corrompido: começa vazio
            }
        }
        loaded = true
    }

    /** Da mais antiga pra mais nova (a mais nova fica embaixo, perto da barra de digitação). */
    @Synchronized
    fun snapshot(): List<NoteItem> = items.toList()

    @Synchronized
    fun add(text: String) {
        if (text.isBlank()) return
        items.add(NoteItem(System.nanoTime(), text, System.currentTimeMillis()))
        save()
    }

    /** Troca o texto de uma anotação (mantém a posição e a data). */
    @Synchronized
    fun update(id: Long, text: String) {
        if (text.isBlank()) return
        val i = items.indexOfFirst { it.id == id }
        if (i < 0) return
        items[i] = items[i].copy(text = text)
        save()
    }

    @Synchronized
    fun delete(id: Long) {
        items.removeAll { it.id == id }
        save()
    }

    private fun save() {
        val arr = JSONArray()
        for (n in items) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("text", n.text)
            o.put("time", n.time)
            arr.put(o)
        }
        try {
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // sem espaço / sem permissão: ignora
        }
    }
}
