package com.clipplus

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.content.FileProvider
import com.clipplus.engine.ChangeClipboardActivity
import com.clipplus.engine.ClipboardDetection
import com.clipplus.engine.ClipboardLogDetector
import com.clipplus.engine.LanguageDetector
import java.io.File

/**
 * Captura: motor de detecção adaptado do XClipper (Apache 2.0), veja a pasta engine/.
 * Painel (Win+V / Win+.), overlay e colagem: código próprio.
 */
class ClipAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClipAccessibilityService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var cm: ClipboardManager
    private lateinit var detector: ClipboardDetection
    private lateinit var logDetector: ClipboardLogDetector
    private val handler = Handler(Looper.getMainLooper())

    // Painel já montado de antemão: abrir é só colocar na tela (instantâneo)
    private var panelView: PanelView? = null
    private var shown = false

    private var runForNextEventAlso = false
    private var editableNode: AccessibilityNodeInfo? = null

    private val panelCallbacks = object : PanelView.Callbacks {
        override fun onPickClip(item: ClipItem) {
            val path = item.imagePath
            if (path != null) copyImage(path) else pasteText(item.text ?: "")
        }

        override fun onPickSymbol(text: String, tab: Int) {
            if (tab == PanelView.TAB_EMOJI) Recents.add(this@ClipAccessibilityService, text)
            pasteText(text)
        }

        override fun onClose() {
            hidePanel()
        }
    }

    // Android 9 e anterior: o sistema avisa o app em segundo plano, então isso já resolve sozinho
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (ClipCapture.ignoreNext) {
            ClipCapture.ignoreNext = false
        } else {
            ClipCapture.capture(this)
        }
    }

    override fun onCreate() {
        super.onCreate()
        detector = ClipboardDetection(LanguageDetector.getCopyForLocale(applicationContext))
        logDetector = ClipboardLogDetector.newInstanceCompat(applicationContext)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ClipStore.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        ClipStore.onChange = { handler.post { if (shown) panelView?.onStoreChanged() } }
        panelView = PanelView(this, PanelView.TAB_CLIP, panelCallbacks)

        logDetector.registerListener(object : ClipboardLogDetector.Listener {
            override fun onClipboardEventDetected() {
                if (!runForNextEventAlso && !ChangeClipboardActivity.running) launchReader()
            }

            override fun onPermissionNotGranted() {}
        })
        refreshAdvancedDetection()
    }

    /**
     * Liga a detecção por logcat se as permissões (READ_LOGS + exibir sobre outros apps) já foram liberadas.
     * Retorna true se estiver rodando.
     */
    fun refreshAdvancedDetection(): Boolean {
        if (!ClipboardLogDetector.isDetectionCompatible(this)) return false
        if (!logDetector.isStarted()) logDetector.startDetecting()
        return logDetector.isStarted()
    }

    override fun onDestroy() {
        hidePanel()
        try {
            logDetector.dispose()
        } catch (e: Exception) {
            // ignora
        }
        try {
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // ignora
        }
        ClipStore.onChange = null
        panelView = null
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------ detectar "copiar" (motor do XClipper)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        try {
            detector.addEvent(event.eventType)

            // Eventos do nosso próprio painel/tela transparente não contam como cópia
            if (event.packageName?.toString() == packageName) return

            val src = event.source
            if (src != null && src.isEditable) editableNode = src

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && detector.getSupportedEventTypes(event)) {
                runForNextEventAlso = true
                launchReader()
                return
            }

            if (runForNextEventAlso) {
                runForNextEventAlso = false
                launchReader()
            }
        } catch (e: Exception) {
            // nunca derruba o serviço
        }
    }

    /** Abre a tela transparente que lê o clipboard (Android 10+). */
    private fun launchReader() {
        try {
            val i = Intent(this, ChangeClipboardActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            startActivity(i)
        } catch (e: Exception) {
            // ignora
        }
    }

    // ------------------------------------------------------------ atalhos de teclado físico

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Esc fecha o painel
        if (shown && event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN) hidePanel()
            return true
        }

        if (event.isMetaPressed) {
            val tab = when (event.keyCode) {
                KeyEvent.KEYCODE_V -> PanelView.TAB_CLIP
                KeyEvent.KEYCODE_PERIOD, KeyEvent.KEYCODE_SEMICOLON -> PanelView.TAB_EMOJI
                else -> return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) toggle(tab)
            return true
        }

        // Ctrl+C / Ctrl+X no teclado físico não gera evento de acessibilidade: lê o clipboard na mão
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            event.isCtrlPressed &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            (event.keyCode == KeyEvent.KEYCODE_C || event.keyCode == KeyEvent.KEYCODE_X)
        ) {
            handler.postDelayed({ launchReader() }, 150)
        }
        return false
    }

    // ------------------------------------------------------------ painel

    fun toggle(tab: Int) {
        val view = panelView
        if (!shown) {
            showPanel(tab)
        } else if (view != null && view.currentTab == tab) {
            hidePanel()
        } else {
            view?.selectTab(tab)
        }
    }

    /** Usado pelos blocos das configurações rápidas: fecha a barra e abre o painel. */
    fun openFromTile(tab: Int) {
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        }
        handler.postDelayed({
            if (!shown) showPanel(tab) else panelView?.selectTab(tab)
        }, 300)
    }

    private fun showPanel(tab: Int) {
        if (shown) return
        val view = panelView ?: PanelView(this, tab, panelCallbacks).also { panelView = it }
        view.selectTab(tab)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, lp)
            shown = true
        } catch (e: Exception) {
            toast("Não consegui abrir o painel")
        }
    }

    fun hidePanel() {
        if (!shown) return
        shown = false
        val view = panelView ?: return
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // já removido
        }
    }

    // ------------------------------------------------------------ colar

    private fun pasteText(text: String) {
        hidePanel()
        ClipCapture.lastOwn = text
        setOwnClip(ClipData.newPlainText("Windows-Transferir", text))
        handler.postDelayed({ doPaste(text) }, 120)
    }

    private fun findTarget(): AccessibilityNodeInfo? {
        val focused = try {
            rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        } catch (e: Exception) {
            null
        }
        if (focused != null) return focused
        val saved = editableNode
        if (saved != null && saved.refresh()) return saved
        return null
    }

    private fun doPaste(text: String) {
        val node = findTarget()
        if (node == null) {
            toast("Toque num campo de texto primeiro. O item já está copiado.")
            return
        }
        node.refresh()
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        if (!ok && node.isEditable) {
            // Alguns apps ignoram o ACTION_PASTE: insere o texto na posição do cursor
            val cur = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
            val rawStart = node.textSelectionStart
            val rawEnd = node.textSelectionEnd
            val start = if (rawStart < 0) cur.length else rawStart.coerceIn(0, cur.length)
            val end = if (rawEnd < 0) start else rawEnd.coerceIn(start, cur.length)
            val merged = cur.substring(0, start) + text + cur.substring(end)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, merged)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }

    private fun copyImage(path: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", File(path))
            hidePanel()
            ClipCapture.lastOwn = null
            setOwnClip(ClipData.newUri(contentResolver, "Windows-Transferir", uri))
            toast("Imagem copiada. Segure no campo e toque em Colar.")
        } catch (e: Exception) {
            toast("Não consegui copiar essa imagem")
        }
    }

    /** Escreve no clipboard sem o histórico registrar de novo. */
    private fun setOwnClip(clip: ClipData) {
        ClipCapture.ignoreNext = true
        cm.setPrimaryClip(clip)
        // Segurança: se o Android não avisar a mudança, não deixa a flag presa
        handler.postDelayed({ ClipCapture.ignoreNext = false }, 700)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
