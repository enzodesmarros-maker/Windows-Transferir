package com.clipplus

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class ClipAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClipAccessibilityService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var cm: ClipboardManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: PanelView? = null
    private var lastLaunch = 0L

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        if (ClipCapture.ignoreNext) {
            ClipCapture.ignoreNext = false
        } else {
            handler.postDelayed({ captureNow() }, 120)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ClipStore.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        ClipStore.onChange = { handler.post { panel?.onStoreChanged() } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não precisamos reagir a eventos; o serviço existe pra atalhos, overlay e colar.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        hidePanel()
        try {
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // ignora
        }
        ClipStore.onChange = null
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ captura

    private fun captureNow() {
        if (ClipCapture.capture(this)) return
        // No Android 10+ o serviço em segundo plano não consegue ler: abre a tela transparente rapidinho.
        if (Build.VERSION.SDK_INT >= 29) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastLaunch < 800) return
            lastLaunch = now
            try {
                val i = Intent(this, ClipReaderActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                startActivity(i)
            } catch (e: Exception) {
                // ignora
            }
        }
    }

    // ------------------------------------------------------------ atalhos de teclado físico

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Esc fecha o painel
        if (panel != null && event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN) handler.post { hidePanel() }
            return true
        }
        if (!event.isMetaPressed) return false
        val tab = when (event.keyCode) {
            KeyEvent.KEYCODE_V -> PanelView.TAB_CLIP
            KeyEvent.KEYCODE_PERIOD, KeyEvent.KEYCODE_SEMICOLON -> PanelView.TAB_EMOJI
            else -> return false
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            handler.post { toggle(tab) }
        }
        return true
    }

    // ------------------------------------------------------------ painel

    fun toggle(tab: Int) {
        val p = panel
        if (p == null) {
            showPanel(tab)
        } else if (p.currentTab == tab) {
            hidePanel()
        } else {
            p.selectTab(tab)
        }
    }

    /** Usado pelos blocos das configurações rápidas: fecha a barra e abre o painel. */
    fun openFromTile(tab: Int) {
        if (Build.VERSION.SDK_INT >= 31) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        }
        handler.postDelayed({
            if (panel == null) showPanel(tab) else panel?.selectTab(tab)
        }, 350)
    }

    private fun showPanel(tab: Int) {
        val view = PanelView(this, tab, object : PanelView.Callbacks {
            override fun onPickClip(item: ClipItem) {
                val path = item.imagePath
                if (path != null) copyImage(path) else pasteText(item.text ?: "")
            }

            override fun onPickSymbol(text: String, tab: Int) {
                if (tab == PanelView.TAB_EMOJI) Recents.add(this@ClipAccessibilityService, text)
                pasteText(text)
            }

            override fun onClose() {
                hidePanel()
            }
        })
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, lp)
            panel = view
        } catch (e: Exception) {
            toast("Não consegui abrir o painel")
        }
    }

    fun hidePanel() {
        val p = panel ?: return
        panel = null
        try {
            wm.removeView(p)
        } catch (e: Exception) {
            // já removido
        }
    }

    // ------------------------------------------------------------ colar

    private fun pasteText(text: String) {
        hidePanel()
        setOwnClip(ClipData.newPlainText("Windows-Transferir", text))
        handler.postDelayed({ doPaste() }, 80)
    }

    private fun doPaste() {
        val root = rootInActiveWindow
        val node = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) {
            toast("Toque num campo de texto primeiro. O item já está copiado.")
            return
        }
        node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    private fun copyImage(path: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", File(path))
            hidePanel()
            setOwnClip(ClipData.newUri(contentResolver, "Windows-Transferir", uri))
            toast("Imagem copiada. Segure no campo e toque em Colar.")
        } catch (e: Exception) {
            toast("Não consegui copiar essa imagem")
        }
    }

    /** Escreve no clipboard sem o histórico registrar de novo. */
    private fun setOwnClip(clip: ClipData) {
        ClipCapture.ignoreNext = true
        cm.setPrimaryClip(clip)
        // Segurança: se o Android não avisar a mudança, não deixa a flag presa
        handler.postDelayed({ ClipCapture.ignoreNext = false }, 700)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
