#!/usr/bin/env bash
# Comando de build usado pelo GitHub Actions (fica no zip: pra trocar debug/release não precisa mexer no workflow).
set -e
gradle assembleRelease --no-daemon --stacktrace
